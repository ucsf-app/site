<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

if ( !function_exists( 'chld_thm_cfg_parent_css' ) ):
    function chld_thm_cfg_parent_css() {
        wp_enqueue_style( 'chld_thm_cfg_parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array(  ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10 );

// END ENQUEUE PARENT ACTION

// Esta es la funcion agregada que hace que vaya primero al login antes de entrar a la pagina ppal. 

add_action( 'template_redirect', 'al_login');
 
function al_login()
    {
        if( ! is_user_logged_in() 
          //  && is_page( array( 'member-page-1', 'member-page-2' ) ) 
        )
        {
            wp_safe_redirect( wp_login_url( get_permalink() ) ); 
            exit();
        }
    }


/**
 * Funcion para redireccionar al usuario luego del login dependiendo de su rol
 */
 
function mi_login_redirect( $url, $request, $user ) {
    if ( $user && is_object( $user ) && is_a( $user, 'WP_User' ) ) {
        if ( $user->has_cap( 'administrator' ) ) {
            $url = admin_url();
        } else {
            $url = home_url( );
        }
    }
    return $url;
}
 
add_filter( 'login_redirect', 'mi_login_redirect', 10, 3 );



// Otra funcion de prueba para cambiar el estilo css de la pagina de login


//Replace style-login.css with the name of your custom CSS file en mi caso login_personalizado.css

function my_custom_login_stylesheet() {
    wp_enqueue_style( 'custom-login', get_stylesheet_directory_uri() . '/login_personalizado.css' );
}

//This loads the function above on the login page
add_action( 'login_enqueue_scripts', 'my_custom_login_stylesheet' );


// Permite agregar un mensaje en el header del login 

function prefix_login_message($message) {
	 if (empty($message)) {
 		return "<center id=\"login-message\"><b>Bienvenido/a</b> a nuestra APP!!!</center>";
 	 }
 	 else {
 		return $message;
 	 }
}

add_filter('login_message', 'prefix_login_message');


/** Shortcode [mostrar_conectado] para que se pueda veer el nombre del usuario que esta logueado */

function ayudawp_mostrar_conectado( $atts ) {
	global $current_user, $user_login;
      	wp_get_current_user();
	add_filter('widget_text', 'apply_shortcodes');
	if ($user_login)
		//return $current_user;
		return '¡Hola ' . $current_user->display_name . '!';
	else
		return '<a href="' . wp_login_url() . ' ">Acceder</a>';
}
add_shortcode( 'mostrar_conectado', 'ayudawp_mostrar_conectado' );

// Ocultar barra de admin a usuarios suscriptores
function ocultar_admin_bar(){
if(current_user_can(‘suscriber’)){
show_admin_bar(false);
}
add_action(‘after_setup_theme’,’ocultar_admin_bar’);

// Load "login-message.css" CSS file stored in active child theme directory
/*
function prefix_login_stylesheet() {
 wp_enqueue_style('custom-login', get_stylesheet_directory_uri() . '/login-message.css');
}
add_action('login_enqueue_scripts', 'prefix_login_stylesheet');
*/

// Esta funcion me permite agregar texto en el footer
/*
add_action( 'login_footer', 'your_custom_footer' );

function your_custom_footer($messagefooter) {
    // Add your content here
     if (empty($messagefooter)) {
 		return "<p class=\"messagef\"><center>Cuidados, recomendaciones, informacion</center></p>";
 	 }
 	 else {
 		return $messagefooter;
 	 }
}
*/