<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
 

jQuery(document).ready(function($){
	
	var imagenAntId = '0'; ////La variable "imagenAntId" se inicializa con un valor string de '0'.
	var imagenAnt = '0'; //La variable "imagenAnt" se inicializa con un valor string de '0'.
  	var ancho = $(window).width();
	
  	//alert(ancho);
	$('.adentro').hide(); //Con esto inicializamos los subelementos en el estado 'escondido'
	
	
	
	$('img').on('click', function cambiarImagen(){
	var imagen = $(this).attr("src"); //La variable "imagen" toma el valor de la URL de la imagen que se clickeo.	
		
		if ((!(imagenAntId === '0')) && (!(imagenAnt === imagen ))){ //Si NO es la primera vez que hacemos click, Y, NO estamos haciendo clic en la misma imagen que la ultima vez entonces entro al if. 
         	$('.adentro').slideUp(500); //Se oculta cualquier submenu que se haya estado mostrando hasta el momento.
			imagenAnt = imagenAnt.replace('Celeste','Blanco'); //Reemplazo en el string de la URL 'Blanco' por 'Celeste'
			$(document.getElementById(imagenAntId)).attr('src',imagenAnt); //Cambio la imagen por la del estado de "menu cerrado clickear para abrir". Vale decir la que lleva 'Blanco en su nombre'
			$(document.getElementById(imagenAntId)).removeClass('show'); //Quito la clase show para dejarla como si no hubiese sido clickeada. Por si se clickea nuevamente en la misma imagen y se saltea este if.
		};

		imagenAntId = $(this).attr('id'); //Guardo el id de la imagen que fue clickeada para poder utilizarlo en el "if statement" anterior de ser necesario.

		if (!$(this).hasClass ('show')) { //Si la 'img' clickeada no tiene la clase ".show" entonces...
			$(this).parent().nextAll('.adentro').slideDown(500); //Se mostraran todos los elementos con la clase '.adentro' que se encuentren "a la misma altura" (es decir que sean "hermanos" o "siblings") del "padre" en el DOM de 'img' (en este caso serian los "hermanos" de 'a')
			imagen = imagen.replace('Blanco','Celeste'); //Tomo el nombre de la URL en imagen y reemplazo 'Blanco' por 'Celeste'. SIEMPRE SEGUIR LA CONVENCION DE QUE LOS NOMBRES SEAN IGUALES Y QUE TERMINEN CON 'Blanco' o 'Celeste' de otra forma no funcionara
			$(this).attr('src', imagen); //Le pongo al atributo 'src' el valor que tengo en la variable "imagen" es decir cambio una imagen por otra. 'http://localhost/wp-content/uploads/2021/01/Videos-Celestes.png');
			$(this).addClass ('show'); //Le agrego a 'img' la clase ".show" para que al hacer click la proxima vez se ingrese por el "else"
			
		} else { //Si la 'img' clickeada tiene la clase ".show" entonces...
          	$(this).parent().nextAll('.adentro').slideUp(500);
			imagen = imagen.replace('Celeste','Blanco');
			$(this).attr('src', imagen); //'http://localhost/wp-content/uploads/2021/01/Videos-Blanco.png');
			$(this).removeClass('show');
			
		};
		imagenAnt = imagen; //A "imagenAnt" le pongo el valor de "imagen" porque si hago click dos veces sobre la misma imagen de esta forma me salto el primer if.
	});
});

	
</script>
<!-- end Simple Custom CSS and JS -->
