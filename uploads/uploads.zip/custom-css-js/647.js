<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
 

jQuery(document).ready(function( $ ){
  var texto = $('.entry-title').text();
  var title = texto.substring(0,(texto.length)-9);
  var underlined = texto.slice((texto.length)-9);
  
    $('#titulo p').prepend(title);
  	$('.subrayado').prepend(underlined);
});</script>
<!-- end Simple Custom CSS and JS -->
