<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
 

jQuery(document).ready(function($){
  									
                                  	
  									
  									
                                  });</script>
<!-- end Simple Custom CSS and JS -->
