<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
 

jQuery(document).ready(function( $ ){
  var texto = $('.entry-title').text();
  var title = texto.substring(0,(texto.length)-9);
  var underlined = texto.slice((texto.length)-9);
  var falsoHeader = document.getElementById('falso-header');
  var URLactual = jQuery(location).attr('href');
  
  if ((URLactual.includes('actualidad')) || (URLactual.includes('cuidados-personales')) 
      || (URLactual.includes('cultura-y-ocio')) || (URLactual.includes('espiritualidad')) 
      || (URLactual.includes('bienvenido'))){
  										falsoHeader.style.display = 'flex';
                                    }
    $('#titulo p').prepend(title);
  	$('.subrayado').prepend(underlined);
  
  
});</script>
<!-- end Simple Custom CSS and JS -->
