<?php

/*
Plugin Name: WP-Appkit PWA SSL Redirection
Description: WP-Appkit pwa SSL Redirection
Author: Juanma
Author URI: https://jmusacchio.github.io
*/
if ( !class_exists( 'WpAppKitSsl' ) ) {

    class WpAppKitSsl {

        public static function hooks() {
            add_filter( 'wpak_pwa_htaccess_redirect_https', array( __CLASS__, 'wpak_pwa_htaccess_redirect_https' )  ); 
        }

        public static function wpak_pwa_htaccess_redirect_https() {
            return false;
        }
    }

    WpAppKitSsl::hooks();
}